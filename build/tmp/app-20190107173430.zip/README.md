# Magine TV Helpcenter

Zendesk iframe app with a link to Helpcenter, offering a search input.

### The following information is displayed:

* search input text field
* search button, opens link in a new browser tab.

Please submit bug reports to [https://github.com/jiavu](me). Pull requests are welcome.

### Screenshot(s):
nööp.